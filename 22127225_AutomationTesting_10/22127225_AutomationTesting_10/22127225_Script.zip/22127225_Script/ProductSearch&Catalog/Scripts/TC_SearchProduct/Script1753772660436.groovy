import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.util.KeywordUtil
import org.openqa.selenium.Keys
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.WebDriver
import java.util.regex.Pattern

// Mở trang và tìm kiếm từ khóa
WebUI.openBrowser('')
WebUI.navigateToUrl('http://localhost:4200/#/')

// --- Khởi tạo biến
boolean useSlider = MinPrice != null && MaxPrice != null && MinPrice != "" && MaxPrice != ""
String keywordToCheck = Keyword?.trim()
boolean isKeywordEmpty = keywordToCheck == null || keywordToCheck.isEmpty()

// --- Kiểm tra keyword rỗng và không sử dụng slider ---
if (isKeywordEmpty && !useSlider) {
    KeywordUtil.markFailed("[FAILED] ❌ Keyword is empty and no price range is specified. This is an invalid test case.")
    WebUI.closeBrowser()
    return
}

// --- Kiểm tra keyword có chứa ký tự đặc biệt/emoji không (chỉ khi keyword không rỗng) ---
if (!isKeywordEmpty) {
    Pattern specialCharPattern = Pattern.compile("[^a-zA-Z0-9\\s]", Pattern.UNICODE_CHARACTER_CLASS)
    if (specialCharPattern.matcher(keywordToCheck).find()) {
        KeywordUtil.markFailed("[FAILED] ❌ Keyword '$Keyword' contains invalid characters, unicode, or emojis")
        WebUI.closeBrowser()
        return
    }
}


// Thực hiện tìm kiếm
if (!isKeywordEmpty) {
    WebUI.setText(findTestObject('Page_Practice Software Testing - Toolshop/input_search'), Keyword)
}
WebUI.sendKeys(findTestObject('Page_Practice Software Testing - Toolshop/input_search'), Keys.chord(Keys.ENTER))
WebUI.delay(2)

// Nếu không cần lọc giá thì bỏ qua bước kéo slider
float min = useSlider ? Float.parseFloat(MinPrice) : 0
float max = useSlider ? Float.parseFloat(MaxPrice) : Float.MAX_VALUE

if (useSlider) {
    WebDriver driver = com.kms.katalon.core.webui.driver.DriverFactory.getWebDriver()
    Actions actions = new Actions(driver)

    WebElement sliderTrack = WebUiCommonHelper.findWebElement(findTestObject('Page_Practice Software Testing - Toolshop/div_slider_track'), 10)
    WebElement sliderMin = WebUiCommonHelper.findWebElement(findTestObject('Page_Practice Software Testing - Toolshop/slider_min'), 10)
    WebElement sliderMax = WebUiCommonHelper.findWebElement(findTestObject('Page_Practice Software Testing - Toolshop/slider_max'), 10)

    int trackWidth = sliderTrack.getSize().getWidth()
    float defaultMin = 1.0f
    float defaultMax = 100.0f
    float sliderRange = 200.0f
    
    float pixelsPerValue = trackWidth / sliderRange
    
    float dragXMin = (min - defaultMin) * pixelsPerValue
    actions.dragAndDropBy(sliderMin, (int)dragXMin, 0).perform()
    
    WebUI.delay(1)

    float dragXMax = (max - defaultMax) * pixelsPerValue
    actions.dragAndDropBy(sliderMax, (int)dragXMax, 0).perform()

    WebUI.delay(2)
}

// Kiểm tra sản phẩm
List<WebElement> productNames = WebUiCommonHelper.findWebElements(findTestObject('Page_Practice Software Testing - Toolshop/all_product_names'), 10)
List<WebElement> productPrices = WebUiCommonHelper.findWebElements(findTestObject('Page_Practice Software Testing - Toolshop/all_product_prices'), 10)

// --- Logic đánh giá khi không có sản phẩm nào
if (productNames.size() == 0 || productPrices.size() == 0) {
    // Nếu có dùng slider, và không tìm thấy sản phẩm nào thì vẫn pass
    if (useSlider) {
        KeywordUtil.markPassed("[PASSED] ✅ No product found with selected price range.")
    } else {
        // Nếu không có keyword nhưng có sản phẩm, pass
        KeywordUtil.markPassed("[PASSED] ✅ No product found with selected keyword — acceptable.")
    }
    WebUI.closeBrowser()
    return
}


boolean matchedKeyword = false
boolean allPricesValid = true

for (int i = 0; i < productNames.size(); i++) {
    String name = productNames[i].getText().trim()
    String priceText = productPrices[i].getText().replace("\$", "").trim()

    float price = 0
    try {
        price = Float.parseFloat(priceText)
    } catch (Exception e) {
        continue
    }

    // Chỉ kiểm tra từ khóa nếu nó không rỗng
    if (!isKeywordEmpty && name.toLowerCase().contains(Keyword.toLowerCase())) {
        matchedKeyword = true
    }

    if (useSlider && (price < min || price > max)) {
        allPricesValid = false
        KeywordUtil.markFailed("[FAILED] ❌ '$name' price $price out of range $MinPrice - $MaxPrice")
    }
}

// Đánh giá kết quả cuối cùng
if (!isKeywordEmpty && !matchedKeyword) {
    KeywordUtil.markFailed("[FAILED] ❌ No product matches keyword '$Keyword'")
} else if (useSlider && !allPricesValid) {
    KeywordUtil.markFailed("[FAILED] ❌ Some prices out of range")
} else {
    KeywordUtil.markPassed("[PASSED] ✅ All matching products within price range (if applicable).")
}

WebUI.closeBrowser()