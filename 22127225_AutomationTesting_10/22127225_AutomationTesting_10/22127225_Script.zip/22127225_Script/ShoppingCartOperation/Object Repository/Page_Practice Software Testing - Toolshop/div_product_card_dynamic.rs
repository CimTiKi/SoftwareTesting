<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_product_card_dynamic</name>
   <tag></tag>
   <elementGuidId>2c79aa38-efeb-472a-90df-63cc40e6a8af</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h5[contains(text(), '${Keyword}')]/ancestor::a[@class='card']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
