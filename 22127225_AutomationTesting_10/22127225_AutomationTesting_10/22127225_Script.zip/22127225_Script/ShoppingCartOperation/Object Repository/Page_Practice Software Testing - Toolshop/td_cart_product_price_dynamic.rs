<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_cart_product_price_dynamic</name>
   <tag></tag>
   <elementGuidId>2f7195d7-3c89-4e39-9c13-3f803f5f1a69</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[contains(text(), '${Keyword}')]/following-sibling::td[@data-test='product-price']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
