<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cart_quantity_input_in_row</name>
   <tag></tag>
   <elementGuidId>cfb4670e-70a9-4029-b961-0512a471b8c9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//tr[.//span[@data-test='product-title' and contains(text(), '${keyword}')]]//input[@data-test='product-quantity']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
