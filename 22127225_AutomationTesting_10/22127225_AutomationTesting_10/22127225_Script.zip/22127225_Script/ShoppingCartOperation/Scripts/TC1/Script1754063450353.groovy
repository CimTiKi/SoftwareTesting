import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.util.KeywordUtil
import org.openqa.selenium.WebElement
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.model.FailureHandling as FailureHandling

KeywordUtil.logInfo("🔍 Starting test for adding product: " + Keyword)
String errorMessage = null

try {
    WebUI.openBrowser('')
    WebUI.navigateToUrl('http://localhost:4200/#/')
    WebUI.maximizeWindow()

    // Search sản phẩm
    WebUI.setText(findTestObject('Page_Practice Software Testing - Toolshop/input_search'), Keyword)
    WebUI.click(findTestObject('Page_Practice Software Testing - Toolshop/button_search'))
    WebUI.delay(2)

    // Click vào sản phẩm
    TestObject productCard = WebUI.modifyObjectProperty(findTestObject('Page_Practice Software Testing - Toolshop/div_product_card_dynamic'),
        'xpath', 'equals', "//h5[contains(text(), '${Keyword}')]/ancestor::a[@class='card']", true)
    WebUI.click(productCard)
    WebUI.delay(2)

    // Kiểm tra số lượng sản phẩm trước khi thêm vào
    String trimmedQuantity = Quantity.trim()
    boolean isInvalid = false

    if (!trimmedQuantity.isInteger()) {
        KeywordUtil.logInfo("❌ Quantity is not an integer.")
        isInvalid = true
    } else {
        int qty = Integer.parseInt(trimmedQuantity)
        if (qty <= 0) {
            KeywordUtil.logInfo("❌ Quantity is 0 or negative.")
            isInvalid = true
        } else if (qty > 10) {
            KeywordUtil.logInfo("❌ Quantity is greater than 10.")
            isInvalid = true
        }
    }

    if (isInvalid) {
        KeywordUtil.markFailed("❌ Invalid quantity input: '$Quantity'. Test failed as expected.")
        WebUI.closeBrowser()
        return
    }

    // Nhập số lượng và thêm vào giỏ hàng 
    WebUI.setText(findTestObject('Page_Practice Software Testing - Toolshop/input_product_quantity_details'), Quantity)
    WebUI.click(findTestObject('Page_Practice Software Testing - Toolshop/button_add_to_cart_details'))
    WebUI.delay(2)

    // Đến giỏ hàng 
    WebUI.click(findTestObject('Page_Practice Software Testing - Toolshop/cart_icon'))
    WebUI.delay(2)

    // Kiểm tra sản phẩm trong giỏ hàng
    String trimmedKeyword = Keyword.trim()
    String cartRowXpath = "//tr[.//span[@data-test='product-title' and contains(text(), '${trimmedKeyword}')]]"
    TestObject cartRowObject = new TestObject("dynamic_cart_row")
    cartRowObject.addProperty("xpath", ConditionType.EQUALS, cartRowXpath)

    if (WebUI.verifyElementPresent(cartRowObject, 5, FailureHandling.CONTINUE_ON_FAILURE)) {
        KeywordUtil.logInfo("✅ Found product row for: " + trimmedKeyword)

        String quantityInputXpath = cartRowXpath + "//input[@data-test='product-quantity']"
        TestObject quantityInputObject = new TestObject("dynamic_quantity_input")
        quantityInputObject.addProperty("xpath", ConditionType.EQUALS, quantityInputXpath)

        if (WebUI.verifyElementPresent(quantityInputObject, 3, FailureHandling.OPTIONAL)) {
            WebElement quantityInput = WebUiCommonHelper.findWebElement(quantityInputObject, 5)
            String actualQuantity = quantityInput.getAttribute("value")

            String cleanedActual = actualQuantity.replaceAll("[^\\d]", "")
            String cleanedExpected = Quantity.trim().replaceAll("[^\\d]", "")

            if (cleanedActual.equals(cleanedExpected)) {
                KeywordUtil.markPassed("✅ Product '$trimmedKeyword' added to cart with correct quantity: $cleanedExpected")
            } else {
                errorMessage = "❌ Quantity mismatch for '$trimmedKeyword'. Expected: $cleanedExpected, Actual: $cleanedActual"
            }
        } else {
            KeywordUtil.markWarning("⚠ Quantity input not found – skipping quantity check.")
            KeywordUtil.markPassed("✅ Product '$trimmedKeyword' found in cart.")
        }
    } else {
        errorMessage = "❌ Product '$trimmedKeyword' not found in cart."
    }

} catch (Exception e) {
    errorMessage = "❌ Test failed due to exception: " + e.getMessage()
} finally {
    if (errorMessage != null) {
        KeywordUtil.markFailed(errorMessage)
    }
    WebUI.closeBrowser()
}
